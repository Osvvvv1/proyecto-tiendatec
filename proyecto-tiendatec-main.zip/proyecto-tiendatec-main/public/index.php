<html>
<head>
    <title>Tienda Tec</title>
    <link rel="stylesheet" href="assets/css/estilos.css">
</head>
<body>
    <header>
    <h1>Bienvenido a Tienda Tec</h1>
        <nav>
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="productos.php">Catálogo</a></li>
                <li><a href="contacto.php">Contacto</a></li>
             </ul>


        </nav>
    </header>

    <main>
        
            <section>
               <h2>Productos Destacados</h2>
               <p>Encuentra los mejores productos de tecnología en nuestra tienda.</p>
            </section>
    </main>

    <footer>
        <p>&copy; 2026 Tienda Tec. Todos los derechos reservados.</p>
    </footer>

</body>
</html>
